//servidor de cartas
const express = require("express");
const mysql = require("mysql");
const ejs = require("ejs");

const app = express();

//detalles de la conexion
const conexion = mysql.createConnection({
    host : 'localhost',
    user : 'edgar8',
    password : '123456',
    database : 'veterinaria',
})

app.set('view engine','ejs');
app.get('/', (req, res)=>{
    conexion.query('SELECT * FROM mascotas', (error, rows)=>{
        if(error) throw error;
        if(!error){
            console.log(rows);
            res.render('cards',{rows});
        }
    })
})//fin del app.get

app.use(express.static(__dirname + '/public'));
app.listen(5000, function(){
    console.log('servidor en linea')
})

