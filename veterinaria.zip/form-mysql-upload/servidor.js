const express = require("express");
const mysql = require("mysql");
//const multer = require("multer");

const app = express();
const bodyParser = require("body-parser");

app.use(express.static(__dirname));
app.use(express.json());
app.use(express.urlencoded({
    extended: true
}))

//detalles de conexion 
var con = mysql.createConnection({
    host : 'localhost',
    user : 'edgar8',
    password : '123456',
    database : 'veterinaria',
})

//configuracion de multer
//const upload = multer({
    //dest : 'public/imagenes',
    //fileFilter : function(req, file, cb){
        //if(!file.originalname.match(/\.(jpg|jpeg)$/)){
           // return cb(new Error('solo se permiten archivos JPG'));
        //}
        //cb(null, true);
   // }//fin del filefilter
//})//fin del multer




//consulta para mostrar datos en el select opction de la bd
app.set('view engine','ejs');
app.get('/', (req, res)=>{
    con.query('SELECT id_cliente FROM clientes', (error, rows)=>{
        if(error) throw error;
        if(!error){
            console.log(rows);
            res.render('Fmembresia',{rows});
        }
    })
})//fin del app.get

//correr servidor
app.use(express.static(__dirname + '/public'));
app.listen(4000, function(){
    console.log('servidor en linea')
})

//accion del formulario para registrar
app.use(bodyParser.urlencoded({extended: true }))
app.post('/registra', (req, res) =>{
   
    const  {tipo1, fechai, fechav, costo, tipo2} = req.body; 

    let sql = 'INSERT INTO membresias (tipo_membresia, fecha_inicio, fecha_vencimiento, costo, id_cliente) VALUES (?,?,?,?,?)';
    con.query(sql, [tipo1, fechai, fechav, costo, tipo2], (err, res) =>{
        if(err){
            console.error('error', err);
        }else {
            console.log("1 record successfully inserted into db");   
        }
    })
})


//app.get("/", (req, res)=>{
    //return res.redirect('F_membresias.html'); 
//}).listen(4000);
//console.log('escuchando el puerto 4000');


